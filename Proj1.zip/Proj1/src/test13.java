
public class test13 {

	public static void main(String[] args) {
		int num=17;
		
		//if(num%2==0) {
		//	System.out.println("Even Number");
		//}else {
		//	System.out.println("Odd Number");
		//}
		
		String output=(num%2==0)?"Even Number":"Odd Number";
		System.out.println(output);
			
		}

	}


