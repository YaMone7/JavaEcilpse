
public class test9 {

	public static void main(String[] args) {
		int a=10;  
		int b=5;  
		int min=(a<b)?a:b;  
		System.out.println(min);  
	
		

	}

}
