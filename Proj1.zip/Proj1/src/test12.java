
public class test12 {

	public static void main(String[] args) {
		int age=20;
		
		if(age>18) {
			System.out.println("Age is greather than 18");
		}

	}

}
