
public class test2 {

	public static void main(String[] args) {
float f=10.5f;
int a=(int)f;
System.out.println(f);
System.out.println(a);

System.out.println(10*10/5+3-1*4/2);
	}

}
