
public class test1 {

	public static void main(String[] args) {
		int a=10;
		int b=10;
		int c=a+b;
		float f=a;
		System.out.println(c);
		System.out.println(a);
		System.out.println(f);

	}

}
