
public class test3 {

	public static void main(String[] args) {
		int a=110;
		byte b=(byte)a;
		System.out.println(a);
		System.out.print(b);

	}

}
