
public class test7 {

	public static void main(String[] args) {
		int x=10;
		System.out.println(x<<2);
		System.out.println(x<<3);
		System.out.println(20<<3);
		System.out.println(20<<4);
		
		
		System.out.println(x>>2);
		System.out.println(x>>3);
		System.out.println(20>>3);
		System.out.println(20>>4);
		
		

	}

}
