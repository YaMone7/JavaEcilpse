
public class test4 {

	public static void main(String[] args) {
		int a=10;
		int b=15;
		byte c=(byte)(a+b);
		System.out.print(c);

	}

}
