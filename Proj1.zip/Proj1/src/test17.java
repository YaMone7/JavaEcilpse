
public class test17 {

	public static void main(String[] args) {
		int age=22;    
	    int weight=55;  
	    
	       if(age>=25){      
	        if(weight>50){    
	            System.out.println("You are eligible to donate blood");    
	        } else{  
	            System.out.println("You are not eligible to donate blood");    
	        }  
	    } else{  
	      System.out.println("Age must be greater than 18");  

	}
	}

}
